#!/usr/bin/env python3
"""
PG Module 6C — Hyper-rigorous real-environment validation on India sanitation data.

This script has three layers:

A. Actual-implementation PG bridge using published endline-report treatment effects.
   This uses the real randomized arms described in the report:
     r0 = Control
     r1 = SL only = sanitation loans
     r2 = SL+A = sanitation loans + awareness creation
   It is NOT a microdata re-estimation because the uploaded endline CSV does not expose
   the GP treatment assignment variable.

B. Observational admissible-regime analysis on SBM village data.
   Regimes are real observed sanitation-action configurations, not randomized arms.
   Law semantics: observational / associational / endline cross-sectional.

C. Robustness, epsilon calibration, uncertainty, abstention value, and balance diagnostics.
"""

from pathlib import Path
import json, math, zipfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path("/mnt/data/pg_module6_sanitation_hyperrigor")
RAW = ROOT / "raw" / "IND_2017_ISUSUIE-EL_v01_M_CSV"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

EPS_GRID = np.round(np.arange(0.0, 0.151, 0.005), 3)

def chamber_label(M, eps=0.05):
    M = np.asarray(M, dtype=float)
    if np.nanmax(M) < -eps:
        return "K0"
    winners = []
    for i in range(len(M)):
        if not np.isfinite(M[i]):
            continue
        ok = M[i] > eps
        for j in range(len(M)):
            if i == j:
                continue
            ok = ok and ((M[i] - M[j]) > eps)
        if ok:
            winners.append(f"K{i+1}")
    return winners[0] if len(winners) == 1 else "U"

def chamber_gap(M, eps=0.05):
    M = np.asarray(M, dtype=float)
    lab = chamber_label(M, eps)
    if lab == "U":
        return 0.0
    if lab == "K0":
        return float(np.nanmin(-M - eps))
    i = int(lab[1:]) - 1
    return float(min(M[i] - eps, 0.5 * min(M[i] - M[j] - eps for j in range(len(M)) if j != i)))

def critical_epsilon(M):
    """
    Maximum epsilon for which the current active argmax is PG-certified.
    Returns 0 if tied/undecided/no positive argmax.
    """
    M = np.asarray(M, dtype=float)
    if np.nanmax(M) <= 0:
        return 0.0
    i = int(np.nanargmax(M))
    vals = [M[i]]
    for j in range(len(M)):
        if i != j:
            vals.append(M[i] - M[j])
    return float(max(0.0, min(vals)))

def wilson_ci(x, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    phat = x / n
    denom = 1 + z**2/n
    center = (phat + z**2/(2*n)) / denom
    half = (z*np.sqrt(phat*(1-phat)/n + z**2/(4*n**2))) / denom
    return max(0, center-half), min(1, center+half)

def log_ratio(a, b):
    if a <= 0 and b > 0:
        return -np.inf
    if a > 0 and b > 0:
        return math.log(a/b)
    return np.nan

def conservative_stat_label(summary, regime_col, baseline, active, eps):
    """
    Wilson lower/upper bound statistical chamber certificate.
    Conservative and intentionally hard to certify.
    """
    d = summary.set_index(regime_col).to_dict(orient="index")
    cert=[]
    for k_idx, k in enumerate(active):
        Lk = d[k]["wilson95_low"]
        U0 = d[baseline]["wilson95_high"]
        if Lk <= 0 or U0 <= 0:
            continue
        if math.log(Lk/U0) <= eps:
            continue
        ok = True
        for j in active:
            if j == k:
                continue
            Uj = d[j]["wilson95_high"]
            if Uj <= 0:
                continue
            if math.log(Lk/Uj) <= eps:
                ok = False
                break
        if ok:
            cert.append("K"+str(k_idx+1))
    if len(cert) == 1:
        return cert[0]
    L0 = d[baseline]["wilson95_low"]
    if L0 > 0 and all(math.log(L0/d[j]["wilson95_high"]) > eps for j in active if d[j]["wilson95_high"] > 0):
        return "K0"
    return "U"

def epsilon_calibration_table():
    rows=[]
    for eps in [0, .01, .02, .05, .075, .10, .15, .20]:
        rows.append({
            "epsilon_log_margin": eps,
            "multiplicative_survival_advantage": math.exp(eps),
            "relative_advantage_percent": 100*(math.exp(eps)-1),
        })
    return pd.DataFrame(rows)

def cramers_v(table):
    """Cramer's V without scipy dependency."""
    obs = np.asarray(table, dtype=float)
    n = obs.sum()
    if n == 0:
        return np.nan
    row = obs.sum(axis=1, keepdims=True)
    col = obs.sum(axis=0, keepdims=True)
    expected = row @ col / n
    mask = expected > 0
    chi2 = ((obs[mask]-expected[mask])**2/expected[mask]).sum()
    r, k = obs.shape
    return float(np.sqrt((chi2/n) / max(1, min(k-1, r-1))))

def summarize_regime(df, regime_col, outcome_col):
    g = df.groupby(regime_col, dropna=False)
    rows=[]
    for regime, sub in g:
        if pd.isna(regime):
            continue
        y = sub[outcome_col].dropna()
        x = int(y.sum())
        n = int(len(y))
        lo, hi = wilson_ci(x,n)
        rows.append({
            "regime": regime,
            "n": n,
            "successes": x,
            "survival": x/n if n else np.nan,
            "wilson95_low": lo,
            "wilson95_high": hi,
            "mean_new_toilets_F154": pd.to_numeric(sub.get("F154", pd.Series(dtype=float)), errors="coerce").mean() if "F154" in sub else np.nan,
            "median_new_toilets_F154": pd.to_numeric(sub.get("F154", pd.Series(dtype=float)), errors="coerce").median() if "F154" in sub else np.nan,
        })
    return pd.DataFrame(rows)

def pg_from_summary(summary, baseline, active, eps):
    d = summary.set_index("regime")["survival"].to_dict()
    S0 = d[baseline]
    M = np.array([log_ratio(d[a], S0) for a in active], dtype=float)
    return M, chamber_label(M, eps), chamber_gap(M, eps), critical_epsilon(M)

def bootstrap_regime_margins(df, regime_col, outcome_col, baseline, active, B=5000, seed=7, smooth=True):
    rng = np.random.default_rng(seed)
    groups = {r: sub.reset_index(drop=True) for r, sub in df.groupby(regime_col)}
    rows=[]
    for b in range(B):
        rates={}
        for r, sub in groups.items():
            idx = rng.choice(np.arange(len(sub)), size=len(sub), replace=True)
            x = float(sub.iloc[idx][outcome_col].sum())
            n = float(len(sub))
            if smooth:
                rates[r] = (x + 0.5)/(n + 1.0)
            else:
                rates[r] = x/n if n else np.nan
        S0 = rates[baseline]
        M = np.array([log_ratio(rates[a], S0) for a in active], dtype=float)
        # Also record argmax label if active selected.
        best = int(np.nanargmax(M)) + 1
        rows.append({
            "bootstrap_id": b,
            **{f"S_{r}": rates[r] for r in [baseline]+active if r in rates},
            **{f"M{i+1}": M[i] for i in range(len(active))},
            "active_argmax_label": f"K{best}",
            "critical_epsilon": critical_epsilon(M),
            **{f"label_eps_{eps:.3f}": chamber_label(M, eps) for eps in [0, .02, .05, .10]},
        })
    return pd.DataFrame(rows)

def selector_instability(boot, active_count, point_label, eps=.05):
    """
    Bootstrap regret/stability diagnostics. This is not causal validation;
    it quantifies how costly a forced selection is under resampling.
    """
    Mcols=[f"M{i+1}" for i in range(active_count)]
    M = boot[Mcols].to_numpy()
    best_vals = np.nanmax(M, axis=1)
    rows=[]
    candidate_labels=[f"K{i+1}" for i in range(active_count)]
    for lab in candidate_labels:
        idx=int(lab[1:])-1
        regret=best_vals - M[:,idx]
        rows.append({
            "selector": lab,
            "mean_bootstrap_regret": float(np.nanmean(regret)),
            "median_bootstrap_regret": float(np.nanmedian(regret)),
            "p90_bootstrap_regret": float(np.nanquantile(regret, .9)),
            "probability_is_argmax": float(np.mean(boot["active_argmax_label"] == lab)),
            "probability_pg_certified_at_eps_0.05": float(np.mean(boot[f"label_eps_{eps:.3f}"] == lab)),
        })
    rows.append({
        "selector": "PG_abstain_if_U",
        "mean_bootstrap_regret": np.nan,
        "median_bootstrap_regret": np.nan,
        "p90_bootstrap_regret": np.nan,
        "probability_is_argmax": np.nan,
        "probability_pg_certified_at_eps_0.05": float(np.mean(boot[f"label_eps_{eps:.3f}"] == point_label)) if point_label != "U" else 0.0,
    })
    return pd.DataFrame(rows)

# ---------------------------------------------------------------------
# A. Published implementation bridge.
# ---------------------------------------------------------------------
# Extracted from endline report Table 21 (client households), using control means and ITT coefficients.
# These are not re-estimated from the uploaded endline CSV because arm assignment is not exposed.
published = [
    {"outcome": "toilet_uptake", "control_mean": 0.451, "SL_only_effect": 0.0895, "SL_only_se": 0.0275, "SLA_effect": 0.0438, "SLA_se": 0.0284},
    {"outcome": "toilet_in_use", "control_mean": 0.389, "SL_only_effect": 0.0991, "SL_only_se": 0.0253, "SLA_effect": 0.0288, "SLA_se": 0.0260},
    {"outcome": "not_all_OD", "control_mean": 1-0.603, "SL_only_effect": 0.110, "SL_only_se": 0.0258, "SLA_effect": 0.0326, "SLA_se": 0.0274},
]
pub_rows=[]
for r in published:
    S0=r["control_mean"]
    S1=S0+r["SL_only_effect"]
    S2=S0+r["SLA_effect"]
    M=np.array([log_ratio(S1,S0), log_ratio(S2,S0)])
    for eps in [0, .02, .05, .10]:
        # Point label
        point=chamber_label(M,eps)
        # Conservative interval using reported coefficient SE only; baseline uncertainty unavailable.
        S1_low=S0+r["SL_only_effect"]-1.96*r["SL_only_se"]
        S2_high=S0+r["SLA_effect"]+1.96*r["SLA_se"]
        S2_low=S0+r["SLA_effect"]-1.96*r["SLA_se"]
        S1_high=S0+r["SL_only_effect"]+1.96*r["SL_only_se"]
        # Active certificate conditions for K1/K2 under approximate treatment-effect uncertainty.
        stat="U"
        if S1_low>0 and S1_low/S0>math.exp(eps) and S1_low/S2_high>math.exp(eps):
            stat="K1"
        if S2_low>0 and S2_low/S0>math.exp(eps) and S2_low/S1_high>math.exp(eps):
            stat="K2" if stat=="U" else "MULTIPLE"
        pub_rows.append({
            "outcome": r["outcome"],
            "epsilon": eps,
            "S_control": S0,
            "S_SL_only": S1,
            "S_SL_plus_awareness": S2,
            "M1_SL_only": M[0],
            "M2_SL_plus_awareness": M[1],
            "critical_epsilon_point": critical_epsilon(M),
            "point_pg_label": point,
            "approx_conservative_stat_label_using_report_SEs": stat,
            "note": "Published Table 21 bridge; treatment-arm microdata assignment unavailable in uploaded CSV."
        })
pub_df=pd.DataFrame(pub_rows)
pub_df.to_csv(OUT/"module6A_published_treatment_arm_pg_bridge.csv", index=False)

# ---------------------------------------------------------------------
# B. Observational SBM regimes.
# ---------------------------------------------------------------------
sbm=pd.read_csv(RAW/"SBM_Anonymized_oct23.csv", low_memory=False)
df=sbm.copy()
df["construction_support"]=(pd.to_numeric(df["E1_02"], errors="coerce")==1).astype(int)
df["awareness_support"]=(pd.to_numeric(df["E1_03"], errors="coerce")==1).astype(int)
df["odf_success"]=(pd.to_numeric(df["F101"], errors="coerce")==1).astype(int)
def support_regime(row):
    c,a=row["construction_support"], row["awareness_support"]
    if c==0 and a==0: return "r0_none"
    if c==1 and a==0: return "r1_construction_only"
    if c==0 and a==1: return "r2_awareness_only"
    if c==1 and a==1: return "r3_combined"
df["support_regime"]=df.apply(support_regime, axis=1)

# Activity intensity regimes from E9/E10.
df["sanitation_activity"]=(pd.to_numeric(df["E9"], errors="coerce")==1).astype(int)
activity_cols=["E10_01","E10_02","E10_03","E10_04","E10_05","E10_06","E10_07","E10_88"]
for c in activity_cols:
    df[c+"_yes"]=(pd.to_numeric(df[c], errors="coerce")==1).astype(int)
df["activity_type_count"]=df[[c+"_yes" for c in activity_cols]].sum(axis=1)
def intensity_regime(row):
    if row["sanitation_activity"]==0: return "r0_no_activity"
    if row["activity_type_count"]<=2: return "r1_low_activity"
    return "r2_high_activity"
df["intensity_regime"]=df.apply(intensity_regime, axis=1)

df[["gp","district","block","support_regime","intensity_regime","odf_success","construction_support","awareness_support","sanitation_activity","activity_type_count","F101","F154","F154B"]].to_csv(OUT/"module6_analysis_dataset.csv", index=False)

# Support summary
support_summary=summarize_regime(df, "support_regime", "odf_success")
support_order=["r0_none","r1_construction_only","r2_awareness_only","r3_combined"]
support_summary["order"]=support_summary["regime"].map({r:i for i,r in enumerate(support_order)})
support_summary=support_summary.sort_values("order").drop(columns="order")
support_summary.to_csv(OUT/"module6B_support_composition_summary.csv", index=False)

# Support PG
support_active=["r1_construction_only","r2_awareness_only","r3_combined"]
support_rows=[]
M0,_,_,_=pg_from_summary(support_summary, "r0_none", support_active, 0.05)
for eps in EPS_GRID:
    M,label,gap,crit=pg_from_summary(support_summary, "r0_none", support_active, float(eps))
    support_rows.append({
        "epsilon": eps,
        "M1_construction_only": M[0],
        "M2_awareness_only": M[1],
        "M3_combined": M[2],
        "point_label": label,
        "gap": gap,
        "critical_epsilon_point": crit,
        "wilson_stat_label": conservative_stat_label(support_summary, "regime", "r0_none", support_active, float(eps)),
        "epsilon_relative_advantage_percent": 100*(math.exp(float(eps))-1),
    })
support_pg=pd.DataFrame(support_rows)
support_pg.to_csv(OUT/"module6B_support_composition_pg_epsilon_sweep.csv", index=False)

support_boot=bootstrap_regime_margins(df.rename(columns={"support_regime":"regime"}), "regime", "odf_success", "r0_none", support_active, B=10000, seed=61)
support_boot.to_csv(OUT/"module6B_support_composition_bootstrap.csv", index=False)
support_boot_dist=[]
for eps in [0,.02,.05,.10]:
    col=f"label_eps_{eps:.3f}"
    dist=support_boot[col].value_counts(normalize=True).reset_index()
    dist.columns=["label","probability"]
    dist["epsilon"]=eps
    support_boot_dist.append(dist)
support_boot_dist=pd.concat(support_boot_dist, ignore_index=True)
support_boot_dist.to_csv(OUT/"module6B_support_composition_bootstrap_chambers.csv", index=False)
support_selector=selector_instability(support_boot, 3, "U", eps=.05)
support_selector.to_csv(OUT/"module6B_support_composition_selector_instability.csv", index=False)

# Intensity summary/PG
int_summary=summarize_regime(df, "intensity_regime", "odf_success")
int_order=["r0_no_activity","r1_low_activity","r2_high_activity"]
int_summary["order"]=int_summary["regime"].map({r:i for i,r in enumerate(int_order)})
int_summary=int_summary.sort_values("order").drop(columns="order")
int_summary.to_csv(OUT/"module6C_activity_intensity_summary.csv", index=False)

int_active=["r1_low_activity","r2_high_activity"]
int_rows=[]
for eps in EPS_GRID:
    M,label,gap,crit=pg_from_summary(int_summary, "r0_no_activity", int_active, float(eps))
    int_rows.append({
        "epsilon": eps,
        "M1_low_activity": M[0],
        "M2_high_activity": M[1],
        "point_label": label,
        "gap": gap,
        "critical_epsilon_point": crit,
        "wilson_stat_label": conservative_stat_label(int_summary, "regime", "r0_no_activity", int_active, float(eps)),
        "epsilon_relative_advantage_percent": 100*(math.exp(float(eps))-1),
    })
int_pg=pd.DataFrame(int_rows)
int_pg.to_csv(OUT/"module6C_activity_intensity_pg_epsilon_sweep.csv", index=False)

int_boot=bootstrap_regime_margins(df.rename(columns={"intensity_regime":"regime"}), "regime", "odf_success", "r0_no_activity", int_active, B=10000, seed=62)
int_boot.to_csv(OUT/"module6C_activity_intensity_bootstrap.csv", index=False)
int_boot_dist=[]
for eps in [0,.02,.05,.10]:
    col=f"label_eps_{eps:.3f}"
    dist=int_boot[col].value_counts(normalize=True).reset_index()
    dist.columns=["label","probability"]
    dist["epsilon"]=eps
    int_boot_dist.append(dist)
int_boot_dist=pd.concat(int_boot_dist, ignore_index=True)
int_boot_dist.to_csv(OUT/"module6C_activity_intensity_bootstrap_chambers.csv", index=False)
int_label_005=int_pg.loc[np.isclose(int_pg["epsilon"], .05), "point_label"].iloc[0]
int_selector=selector_instability(int_boot, 2, int_label_005, eps=.05)
int_selector.to_csv(OUT/"module6C_activity_intensity_selector_instability.csv", index=False)

# Balance/confounding diagnostics for observational regimes.
def balance_diagnostics(df, regime_col):
    rows=[]
    for cov in ["district","block"]:
        tab=pd.crosstab(df[regime_col], df[cov])
        rows.append({
            "regime_family": regime_col,
            "covariate": cov,
            "cramers_v": cramers_v(tab),
            "table": str(tab.to_dict())
        })
    return pd.DataFrame(rows)
bal=pd.concat([balance_diagnostics(df,"support_regime"), balance_diagnostics(df,"intensity_regime")], ignore_index=True)
bal.to_csv(OUT/"module6_observational_balance_diagnostics.csv", index=False)

# Epsilon calibration.
epsilon_calibration_table().to_csv(OUT/"module6_epsilon_calibration.csv", index=False)

# Robustness atlas summary.
atlas_rows=[
    {
        "analysis": "published_report_treatment_arm_bridge",
        "law_semantics": "causal_ITT_published_report_not_microdata_reestimate",
        "baseline": "Control",
        "active_regimes": "SL only; SL+A",
        "primary_result_eps_0.05": "; ".join(pub_df[pub_df["epsilon"]==.05].apply(lambda r: f'{r.outcome}: point={r.point_pg_label}, stat={r.approx_conservative_stat_label_using_report_SEs}', axis=1)),
        "main_risk": "Uploaded CSV lacks arm assignment, so this bridge uses published coefficients."
    },
    {
        "analysis": "support_composition_observational",
        "law_semantics": "observational_associational",
        "baseline": "no construction support, no awareness support",
        "active_regimes": "construction only; awareness only; combined",
        "primary_result_eps_0.05": support_pg.loc[np.isclose(support_pg["epsilon"], .05), "point_label"].iloc[0] + " / stat " + support_pg.loc[np.isclose(support_pg["epsilon"], .05), "wilson_stat_label"].iloc[0],
        "main_risk": "Small baseline/support-only cells and strong possible confounding by village context."
    },
    {
        "analysis": "activity_intensity_observational",
        "law_semantics": "observational_associational",
        "baseline": "no sanitation activity",
        "active_regimes": "low activity intensity; high activity intensity",
        "primary_result_eps_0.05": int_pg.loc[np.isclose(int_pg["epsilon"], .05), "point_label"].iloc[0] + " / stat " + int_pg.loc[np.isclose(int_pg["epsilon"], .05), "wilson_stat_label"].iloc[0],
        "main_risk": "Activity intensity is endogenous to need, state capacity, and SBM implementation."
    }
]
atlas=pd.DataFrame(atlas_rows)
atlas.to_csv(OUT/"module6_validation_atlas_summary.csv", index=False)

# ---------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------
# Published bridge: margins by outcome.
fig_df=pub_df[pub_df["epsilon"]==.05].copy()
x=np.arange(len(fig_df)); width=.35
plt.figure(figsize=(8,4.8))
plt.bar(x-width/2, fig_df["M1_SL_only"], width, label="SL only")
plt.bar(x+width/2, fig_df["M2_SL_plus_awareness"], width, label="SL+A")
plt.axhline(.05, linestyle="--", linewidth=1, label="epsilon=0.05")
plt.xticks(x, fig_df["outcome"], rotation=15, ha="right")
plt.ylabel("log survival margin")
plt.title("Module 6A: PG bridge from published treatment-arm estimates")
plt.legend()
plt.tight_layout()
plt.savefig(FIG/"fig_module6A_published_treatment_bridge_margins.png", dpi=200)
plt.close()

# Support survival with CIs.
plot=support_summary.set_index("regime").loc[support_order].reset_index()
x=np.arange(len(plot)); y=plot["survival"].to_numpy()
yerr=np.vstack([y-plot["wilson95_low"].to_numpy(), plot["wilson95_high"].to_numpy()-y])
plt.figure(figsize=(8,4.8))
plt.bar(x,y)
plt.errorbar(x,y,yerr=yerr,fmt="none",capsize=4)
plt.xticks(x, ["none","construction","awareness","combined"], rotation=15, ha="right")
plt.ylabel("ODF survival")
plt.title("Module 6B: ODF survival by support-composition regime")
plt.tight_layout()
plt.savefig(FIG/"fig_module6B_support_composition_survival.png", dpi=200)
plt.close()

# Support bootstrap distribution.
dist005=support_boot_dist[np.isclose(support_boot_dist["epsilon"], .05)]
plt.figure(figsize=(6,4.5))
plt.bar(dist005["label"], dist005["probability"])
plt.ylabel("bootstrap probability")
plt.title("Module 6B: support-composition chamber instability")
plt.tight_layout()
plt.savefig(FIG/"fig_module6B_support_bootstrap_chambers.png", dpi=200)
plt.close()

# Intensity survival with CIs.
plot=int_summary.set_index("regime").loc[int_order].reset_index()
x=np.arange(len(plot)); y=plot["survival"].to_numpy()
yerr=np.vstack([y-plot["wilson95_low"].to_numpy(), plot["wilson95_high"].to_numpy()-y])
plt.figure(figsize=(7,4.6))
plt.bar(x,y)
plt.errorbar(x,y,yerr=yerr,fmt="none",capsize=4)
plt.xticks(x, ["no activity","low activity","high activity"], rotation=15, ha="right")
plt.ylabel("ODF survival")
plt.title("Module 6C: ODF survival by activity-intensity regime")
plt.tight_layout()
plt.savefig(FIG/"fig_module6C_activity_intensity_survival.png", dpi=200)
plt.close()

# Epsilon robustness lines.
plt.figure(figsize=(8,4.8))
# Encode labels as numbers
labmap={"K0":0,"K1":1,"K2":2,"K3":3,"U":4}
plt.plot(support_pg["epsilon"], [labmap[x] for x in support_pg["point_label"]], marker="o", label="support point")
plt.plot(support_pg["epsilon"], [labmap[x] for x in support_pg["wilson_stat_label"]], marker="o", label="support statistical")
plt.plot(int_pg["epsilon"], [labmap[x] for x in int_pg["point_label"]], marker="o", label="intensity point")
plt.plot(int_pg["epsilon"], [labmap[x] for x in int_pg["wilson_stat_label"]], marker="o", label="intensity statistical")
plt.yticks([0,1,2,3,4], ["K0","K1","K2","K3","U"])
plt.xlabel("epsilon")
plt.ylabel("PG chamber")
plt.title("Module 6: epsilon robustness")
plt.legend()
plt.tight_layout()
plt.savefig(FIG/"fig_module6_epsilon_robustness.png", dpi=200)
plt.close()

# Balance Cramer's V.
plt.figure(figsize=(7,4.5))
plt.bar(bal["regime_family"]+" / "+bal["covariate"], bal["cramers_v"])
plt.xticks(rotation=20, ha="right")
plt.ylabel("Cramer's V")
plt.title("Module 6: observational balance/confounding diagnostic")
plt.tight_layout()
plt.savefig(FIG/"fig_module6_balance_cramers_v.png", dpi=200)
plt.close()

# Write memo.
memo = f"""# Module 6C — Hyper-rigorous sanitation validation package

## Status

This package separates three distinct validation layers.

### 6A. Actual randomized implementation bridge

The endline report identifies the implemented randomized arms as:

- Control
- SL only: sanitation loans
- SL+A: sanitation loans plus awareness creation activities

The uploaded CSV files do not expose GP treatment assignment, so this script does not pretend to re-estimate those ITT effects from microdata. Instead, it builds a PG bridge from published Table 21 outcome estimates.

At epsilon = 0.05, the published treatment-arm bridge gives point PG = K1 for toilet uptake, toilet in use, and no-all-open-defecation survival. The conservative statistical label is U for all three under reported coefficient uncertainty, because the published effects are not separated enough for conservative chamber certification.

### 6B. Observational support-composition regimes

Regime coordinates:

- E1_02: support for construction of toilets.
- E1_03: information/awareness creation about sanitation.

Outcome:

- F101 == 1: GP is currently Open Defecation Free.

At epsilon = 0.05, point PG is U and Wilson statistical PG is U.

### 6C. Observational sanitation-activity intensity regimes

Regime coordinates:

- E9: any sanitation activities in last three years.
- E10_*: activity modalities.

At epsilon = 0.05, point PG is K2 for high activity intensity, but Wilson statistical PG is U.

## Why undecided matters

Undecided means the chamber inequalities are not satisfied after the declared tolerance and uncertainty rule. It is not a failed result. In this dataset it protects the analysis from over-selecting regimes whose ODF rates are close, unstable, or confounded.

## Why epsilon = 0.05

Epsilon is a log-survival margin. epsilon = 0.05 corresponds to about a {100*(math.exp(.05)-1):.2f}% multiplicative survival advantage. The package reports epsilon sweeps rather than relying on one arbitrary value.

## Main nonclaim

The observational SBM regime analyses are not causal. They demonstrate PG operation on real admissible regimes, not randomized treatment effects.
"""
(ROOT/"MODULE6_HYPERRIGOR_MEMO.md").write_text(memo)

status = {
    "module": "Module 6C hyper-rigorous sanitation validation",
    "n_sbm_units": int(len(df)),
    "published_bridge": {
        "eps_0.05_point_labels": pub_df[pub_df["epsilon"]==.05][["outcome","point_pg_label","approx_conservative_stat_label_using_report_SEs"]].to_dict(orient="records")
    },
    "support_composition": {
        "eps_0.05_point_label": support_pg.loc[np.isclose(support_pg["epsilon"], .05), "point_label"].iloc[0],
        "eps_0.05_stat_label": support_pg.loc[np.isclose(support_pg["epsilon"], .05), "wilson_stat_label"].iloc[0],
        "critical_epsilon_point": float(support_pg["critical_epsilon_point"].iloc[0]),
        "bootstrap_eps_0.05": support_boot_dist[np.isclose(support_boot_dist["epsilon"], .05)].to_dict(orient="records"),
    },
    "activity_intensity": {
        "eps_0.05_point_label": int_pg.loc[np.isclose(int_pg["epsilon"], .05), "point_label"].iloc[0],
        "eps_0.05_stat_label": int_pg.loc[np.isclose(int_pg["epsilon"], .05), "wilson_stat_label"].iloc[0],
        "critical_epsilon_point": float(int_pg["critical_epsilon_point"].iloc[0]),
        "bootstrap_eps_0.05": int_boot_dist[np.isclose(int_boot_dist["epsilon"], .05)].to_dict(orient="records"),
    },
    "output_files": [p.name for p in OUT.iterdir()],
    "figure_files": [p.name for p in FIG.iterdir()],
}
with open(OUT/"module6_hyperrigor_status.json","w") as f:
    json.dump(status,f,indent=2)

# Zip.
zip_path = ROOT/"pg_module6_hyperrigor_outputs.zip"
with zipfile.ZipFile(zip_path,"w",compression=zipfile.ZIP_DEFLATED) as z:
    for p in ROOT.rglob("*"):
        if p.is_file() and p.name != zip_path.name:
            z.write(p, arcname=p.relative_to(ROOT))

print(json.dumps(status, indent=2))
