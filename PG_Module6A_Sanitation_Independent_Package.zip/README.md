# PG Module 6A — Sanitation Real-Environment Package

## Scope
This is the sanitation real-environment package. It has two layers:

1. **Published randomized-arm bridge**: uses report-level estimates for the actual randomized arms: Control, sanitation loans only, and sanitation loans plus awareness. This is not a microdata re-estimation because the uploaded CSVs did not expose treatment assignment.
2. **Observed admissible-regime atlas**: uses observed village-level sanitation action configurations from the SBM village questionnaire. These regimes are real socioeconomic states/actions, but the law semantics are observational/associational, not causal.

## Core status
- SBM village units: 121.
- Published bridge at epsilon 0.05: [{'outcome': 'toilet_uptake', 'point_pg_label': 'K1', 'approx_conservative_stat_label_using_report_SEs': 'U'}, {'outcome': 'toilet_in_use', 'point_pg_label': 'K1', 'approx_conservative_stat_label_using_report_SEs': 'U'}, {'outcome': 'not_all_OD', 'point_pg_label': 'K1', 'approx_conservative_stat_label_using_report_SEs': 'U'}].
- Support-composition point/statistical label at epsilon 0.05: U / U.
- Activity-intensity point/statistical label at epsilon 0.05: K2 / U.

## Honest interpretation
This module demonstrates real-environment operability and law-semantics discipline. It does not claim causal microdata re-estimation without assignment data.

## Raw data note
The compact package excludes raw CSV data. It includes scripts, outputs, figures, and the memo. Re-run requires the original World Bank microdata package.
