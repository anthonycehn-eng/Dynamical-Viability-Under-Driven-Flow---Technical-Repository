# Validation audit — Module 6A

## Main honesty checks
- The randomized-arm bridge uses published report estimates, not a false microdata re-estimation.
- Observed SBM action regimes are explicitly labeled observational/associational.
- Point PG labels and conservative statistical labels are reported separately.
- Epsilon is treated as a log-survival tolerance and is swept rather than fixed without justification.
- Raw data are excluded from this compact package; scripts and outputs are included.
