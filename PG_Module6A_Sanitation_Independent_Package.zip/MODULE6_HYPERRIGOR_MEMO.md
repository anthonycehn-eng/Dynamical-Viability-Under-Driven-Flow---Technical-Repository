# Module 6C — Hyper-rigorous sanitation validation package

## Status

This package separates three distinct validation layers.

### 6A. Actual randomized implementation bridge

The endline report identifies the implemented randomized arms as:

- Control
- SL only: sanitation loans
- SL+A: sanitation loans plus awareness creation activities

The uploaded CSV files do not expose GP treatment assignment, so this script does not pretend to re-estimate those ITT effects from microdata. Instead, it builds a PG bridge from published Table 21 outcome estimates.

At epsilon = 0.05, the published treatment-arm bridge gives point PG = K1 for toilet uptake, toilet in use, and no-all-open-defecation survival. The conservative statistical label is U for all three under reported coefficient uncertainty, because the published effects are not separated enough for conservative chamber certification.

### 6B. Observational support-composition regimes

Regime coordinates:

- E1_02: support for construction of toilets.
- E1_03: information/awareness creation about sanitation.

Outcome:

- F101 == 1: GP is currently Open Defecation Free.

At epsilon = 0.05, point PG is U and Wilson statistical PG is U.

### 6C. Observational sanitation-activity intensity regimes

Regime coordinates:

- E9: any sanitation activities in last three years.
- E10_*: activity modalities.

At epsilon = 0.05, point PG is K2 for high activity intensity, but Wilson statistical PG is U.

## Why undecided matters

Undecided means the chamber inequalities are not satisfied after the declared tolerance and uncertainty rule. It is not a failed result. In this dataset it protects the analysis from over-selecting regimes whose ODF rates are close, unstable, or confounded.

## Why epsilon = 0.05

Epsilon is a log-survival margin. epsilon = 0.05 corresponds to about a 5.13% multiplicative survival advantage. The package reports epsilon sweeps rather than relying on one arbitrary value.

## Main nonclaim

The observational SBM regime analyses are not causal. They demonstrate PG operation on real admissible regimes, not randomized treatment effects.
